package cen3031team6.Statistics;

public class Tournament {

  private int id;
  private String name;

  public Tournament(int id, String name) {
    this.id = id;
    this.name = name;
  }

  public int getId() {
    return id;
  }

  public String getName() {
    return name;
  }
}
