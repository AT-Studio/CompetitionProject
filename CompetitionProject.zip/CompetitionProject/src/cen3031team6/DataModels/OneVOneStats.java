package cen3031team6.DataModels;

public class OneVOneStats {

  private String userNameOne;
  private String userNameTwo;
  private String userOneScore;
  private String userTwoScore;

  public String getUserNameOne() {
    return userNameOne;
  }

  public void setUserNameOne(String userNameOne) {
    this.userNameOne = userNameOne;
  }

  public String getUserNameTwo() {
    return userNameTwo;
  }

  public void setUserNameTwo(String userNameTwo) {
    this.userNameTwo = userNameTwo;
  }
}